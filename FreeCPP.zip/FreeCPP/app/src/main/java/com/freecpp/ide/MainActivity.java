package com.freecpp.ide;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.text.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.drawerlayout.widget.DrawerLayout;
import com.freecpp.ide.editor.CppHighlighter;
import com.freecpp.ide.nativebridge.NativeBridge;
import com.freecpp.ide.project.FileManager;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    private EditText editor, termInput; private TextView gutter, terminal, status, title;
    private ScrollView termScroll; private DrawerLayout drawer; private ListView fileList;
    private FileManager fm; private File current; private boolean loading;
    private final Handler h = new Handler();
    private final Runnable autosave = this::save;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        editor = findViewById(R.id.editor); gutter = findViewById(R.id.gutter); terminal = findViewById(R.id.terminal);
        status = findViewById(R.id.status); title = findViewById(R.id.title); termScroll = findViewById(R.id.termScroll);
        termInput = findViewById(R.id.termInput); drawer = findViewById(R.id.drawer); fileList = findViewById(R.id.fileList);
        fm = new FileManager(getFilesDir());

        editor.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int c, int d) {}
            public void afterTextChanged(Editable e) {
                if (loading) return;
                CppHighlighter.apply(e); updateGutter();
                h.removeCallbacks(autosave); h.postDelayed(autosave, 800);
            }
        });
        editor.setOnKeyListener((v, k, ev) -> { updateCursor(); return false; });
        editor.setOnClickListener(v -> updateCursor());
        findViewById(R.id.btnMenu).setOnClickListener(v -> { refreshFiles(); drawer.openDrawer(android.view.Gravity.START); });
        findViewById(R.id.btnNew).setOnClickListener(v -> newFileDialog());
        findViewById(R.id.btnBuild).setOnClickListener(v -> build(false));
        findViewById(R.id.btnRun).setOnClickListener(v -> build(true));
        termInput.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEND) { println("> " + v.getText()); println("[no program running - stdin not connected yet]"); v.setText(""); }
            return true;
        });
        fileList.setOnItemClickListener((p, v, i, id) -> { open(fm.list().get(i)); drawer.closeDrawers(); });
        open(new File(fm.dir(), "main.cpp"));
        println("FreeCPP IDE 0.1.0 - ABI: " + NativeBridge.abi());
    }

    @Override protected void onPause() { super.onPause(); save(); }

    private void open(File f) {
        save();
        try { loading = true; editor.setText(fm.read(f)); current = f; title.setText("FreeCPP - " + f.getName());
              CppHighlighter.apply(editor.getText()); updateGutter(); }
        catch (Exception e) { println("Error opening " + f.getName() + ": " + e); }
        finally { loading = false; }
    }
    private void save() {
        if (current == null) return;
        try { fm.write(current, editor.getText().toString()); } catch (Exception e) { println("Save failed: " + e); }
    }
    private void refreshFiles() {
        List<String> n = new ArrayList<>(); for (File f : fm.list()) n.add(f.getName());
        fileList.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, n) {
            @Override public android.view.View getView(int p, android.view.View c, android.view.ViewGroup g) {
                TextView t = (TextView) super.getView(p, c, g); t.setTextColor(0xFFD4D4D4); return t; }
        });
    }
    private void newFileDialog() {
        EditText in = new EditText(this); in.setHint("name.cpp");
        new AlertDialog.Builder(this).setTitle("New file").setView(in).setPositiveButton("Create", (d, w) -> {
            try { File f = fm.create(in.getText().toString().trim()); refreshFiles(); open(f); drawer.closeDrawers(); }
            catch (Exception e) { println("Create failed: " + e.getMessage()); }
        }).setNegativeButton("Cancel", null).show();
    }
    private void updateGutter() {
        int n = Math.max(1, editor.getLineCount()); StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= n; i++) sb.append(i).append('\n');
        gutter.setText(sb);
    }
    private void updateCursor() {
        int pos = editor.getSelectionStart(); if (pos < 0 || editor.getLayout() == null) return;
        int line = editor.getLayout().getLineForOffset(pos);
        status.setText("Ln " + (line + 1) + ", Col " + (pos - editor.getLayout().getLineStart(line) + 1));
    }
    private void build(boolean run) {
        save();
        File clang = NativeBridge.clang(this);
        if (clang == null) {
            println("[error] Clang toolchain not installed (libclang.so not found).");
            println("        Compiler integration is Milestone 3 - nothing was compiled.");
            return;
        }
        println("[todo] toolchain found at " + clang + " but the build pipeline is not implemented yet.");
    }
    private void println(String s) { terminal.append(s + "\n"); termScroll.post(() -> termScroll.fullScroll(android.view.View.FOCUS_DOWN)); }
}
