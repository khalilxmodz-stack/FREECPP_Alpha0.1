package com.freecpp.ide.nativebridge;

import android.content.Context;
import java.io.File;

/** JNI entry point + toolchain discovery. */
public class NativeBridge {
    static { System.loadLibrary("freecpp"); }
    public static native String abi();

    /** Clang is expected as libclang.so inside nativeLibraryDir (the location from which Android permits exec). */
    public static File clang(Context c) {
        File f = new File(c.getApplicationInfo().nativeLibraryDir, "libclang.so");
        return f.exists() ? f : null;
    }
}
