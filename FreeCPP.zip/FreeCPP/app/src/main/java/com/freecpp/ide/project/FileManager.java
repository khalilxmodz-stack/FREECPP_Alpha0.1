package com.freecpp.ide.project;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal project storage in app-private storage. */
public class FileManager {
    public static final String HELLO = "#include <iostream>\n\nint main() {\n    std::cout << \"Hello, FreeCPP!\" << std::endl;\n    return 0;\n}\n";
    private final File dir;
    public FileManager(File filesDir) {
        dir = new File(filesDir, "projects/Default");
        dir.mkdirs();
        File main = new File(dir, "main.cpp");
        if (!main.exists()) try { write(main, HELLO); } catch (IOException ignored) {}
    }
    public File dir() { return dir; }
    public List<File> list() {
        File[] f = dir.listFiles(); List<File> l = new ArrayList<>();
        if (f != null) { Arrays.sort(f); l.addAll(Arrays.asList(f)); }
        return l;
    }
    public String read(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        }
    }
    public void write(File f, String s) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes(StandardCharsets.UTF_8)); }
    }
    public File create(String name) throws IOException {
        if (name.contains("/") || name.isEmpty()) throw new IOException("Invalid file name");
        File f = new File(dir, name);
        if (f.exists()) throw new IOException("File already exists");
        write(f, ""); return f;
    }
}
