package com.freecpp.ide.editor;

import android.text.Editable;
import android.text.style.ForegroundColorSpan;
import java.util.regex.*;

/** Regex-based C++ highlighter (foundation; a real tokenizer comes in Milestone 2). */
public class CppHighlighter {
    private static final String KW = "alignas|alignof|auto|break|case|catch|class|concept|const|constexpr|continue|default|delete|do|else|enum|explicit|export|extern|false|final|for|friend|goto|if|inline|namespace|new|noexcept|nullptr|operator|override|private|protected|public|requires|return|static|static_assert|struct|switch|template|this|throw|true|try|typedef|typename|union|using|virtual|volatile|while";
    private static final String TY = "bool|char|double|float|int|long|short|signed|unsigned|void|size_t|string|vector|map|unordered_map|set|array|unique_ptr|shared_ptr";
    private static final Pattern P_FN = Pattern.compile("\\b([A-Za-z_]\\w*)(?=\\s*\\()");
    private static final Pattern P_KW = Pattern.compile("\\b(" + KW + ")\\b");
    private static final Pattern P_TY = Pattern.compile("\\b(" + TY + ")\\b");
    private static final Pattern P_NUM = Pattern.compile("\\b(0x[0-9a-fA-F]+|\\d+(\\.\\d+)?([eE][+-]?\\d+)?[fFlLuU]*)\\b");
    private static final Pattern P_PRE = Pattern.compile("^\\s*#.*$", Pattern.MULTILINE);
    private static final Pattern P_STR = Pattern.compile("\"(\\\\.|[^\"\\\\\\n])*\"|'(\\\\.|[^'\\\\\\n])*'");
    private static final Pattern P_CMT = Pattern.compile("//.*$|/\\*[\\s\\S]*?(\\*/|\\z)", Pattern.MULTILINE);

    public static void apply(Editable e) {
        for (ForegroundColorSpan s : e.getSpans(0, e.length(), ForegroundColorSpan.class)) e.removeSpan(s);
        String t = e.toString();
        paint(e, t, P_FN, 0xFFDCDCAA);
        paint(e, t, P_NUM, 0xFFB5CEA8);
        paint(e, t, P_TY, 0xFF4EC9B0);
        paint(e, t, P_KW, 0xFF569CD6);
        paint(e, t, P_PRE, 0xFFC586C0);
        paint(e, t, P_STR, 0xFFCE9178);
        paint(e, t, P_CMT, 0xFF6A9955);
    }
    private static void paint(Editable e, String t, Pattern p, int color) {
        Matcher m = p.matcher(t);
        while (m.find()) e.setSpan(new ForegroundColorSpan(color), m.start(), m.end(), 0);
    }
}
