#include <jni.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_freecpp_ide_nativebridge_NativeBridge_abi(JNIEnv* env, jclass) {
#if defined(__aarch64__)
    return env->NewStringUTF("arm64-v8a");
#elif defined(__arm__)
    return env->NewStringUTF("armeabi-v7a");
#else
    return env->NewStringUTF("unknown");
#endif
}
