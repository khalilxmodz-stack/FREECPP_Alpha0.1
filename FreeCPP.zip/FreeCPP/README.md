# FreeCPP IDE
Free, offline, ad-free C++ IDE for Android (armeabi-v7a + arm64-v8a). Status: Milestone 1 (shell). APK is built by GitHub Actions (.github/workflows/build.yml).
Planned exec architecture: bundle Clang as libclang.so in jniLibs (extractNativeLibs=true), compile user code to a .so, run it in an isolated child process.
